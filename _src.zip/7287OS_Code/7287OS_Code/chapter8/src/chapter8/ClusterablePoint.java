package chapter8;


public interface ClusterablePoint {
      public double getDistance(ClusterablePoint other);
      public String print();
}
