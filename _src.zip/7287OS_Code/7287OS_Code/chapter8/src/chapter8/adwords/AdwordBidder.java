package chapter8.adwords;

public class AdwordBidder {
    String clientID;
    double intialBudget;
    double currentBudget;
    double bid;
}
